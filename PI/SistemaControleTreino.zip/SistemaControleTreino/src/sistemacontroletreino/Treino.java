package sistemacontroletreino;

import java.util.Scanner;

/**
 *
 * @author 
 * Lucas Gonçalves - RGM: 31104894 
 * Joey da Silva Dagmar - RGM: 31619363
 * Beatriz dos Santos Silva - RGM: 31146171 
 * Maria Luísa Cavalcante - RGM: 31200125
 */
public class Treino {     // classe treino é onde as classes intrutor e aluno são relacionadas

    private Aluno cliente;
    private Instrutor treinador;
    private boolean marcado;
    private int pergunta;
    public String treinoH[];
    public String treinoE[];
    public int aluno;

    
    // nesse método o treino só é marcado se o Instrutor estiver presente
    public void marcarTreino(Instrutor i, Aluno a) {
        if (i.getPresente() == true) {
            if (this.marcado == false) {
                Scanner sc = new Scanner(System.in);
                System.out.println("Qual seu objetivo? \n "
                        + "------------------------\n"
                        + "1-Emagrecimento \n"
                        + "2-Ganho de Massa Muscular \n");
                pergunta = sc.nextInt();

                if (pergunta == 1) {
                    System.out.println("Treino para Emagrecimento criado!");
                    this.marcado = true;
                    this.cliente = a;
                    this.treinador = i;
                    System.out.println("Treino marcado!");
                    treinoE = new String[3];
                    treinoE[0] = "A";
                    treinoE[1] = "B";
                    treinoE[2] = "C";

                } else if (pergunta == 2) {
                    System.out.println("Treino para Hipertrofia criado!");
                    this.marcado = true;
                    this.cliente = a;
                    this.treinador = i;
                    System.out.println("Treino marcado!");
                    treinoH = new String[3];
                    treinoH[0] = "A";
                    treinoH[1] = "B";
                    treinoH[2] = "C";
                } else {
                    System.out.println("opção invalida!");

                }
            }
            

        } else {
            this.marcado = false;
            this.cliente = null;
            this.treinador = null;
            System.out.println("Impossibilitado de marcar treino");
        }
    }
    /*
    *Esse metodo treinar, ele faz o controle de qual treino você está realizando
    *quantos treinos faltam para
    */
    public void Treinar() {
        if (this.marcado) {
            for (int treinos = 1; treinos <= 10; treinos++) {
                if (treinos < 11) {
                    if (pergunta == 1) {
                        for (int i = 0; i < treinoE.length; i++) {
                            System.out.println("------------------------------");
                            System.out.println("Hoje é o seu treino: " + treinoE[i]);

                            System.out.println("Hoje é o treino de numero: " + treinos + " faltam "
                                    + (10 - treinos) + " treinos para trocar o seu treino");

                        }
                    } else if (pergunta == 2) {
                        for (int i = 0; i < treinoH.length; i++) {
                            System.out.println("------------------------------");
                            System.out.println("Hoje é o seu treino: " + treinoH[i]);

                            System.out.println("Hoje é o treino de numero: " + treinos
                                    + " de treino faltam " + (10 - treinos)
                                    + " treinos para trocar o seu treino");

                        }
                    }

                } else {
                    System.out.println("Seu treino expirou! \n Favor agendar um novo treino!!!");

                }
            }
        } else {
            System.out.println("O treino não pode acontecer...");
        }
    }

    public Aluno getCliente() {
        return cliente;
    }

    public void setCliente(Aluno cliente) {
        this.cliente = cliente;
    }

    public Instrutor getTreinador() {
        return treinador;
    }

    public void setTreinador(Instrutor treinador) {
        this.treinador = treinador;
    }

    public boolean getMarcado() {
        return marcado;
    }

    public void setMarcado(boolean marcado) {
        this.marcado = marcado;
    }

}
