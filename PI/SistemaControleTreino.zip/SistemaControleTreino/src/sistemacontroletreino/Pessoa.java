package sistemacontroletreino;

/**
 *
 * @author 
 * Lucas Gonçalves - RGM: 31104894
 * Joey da Silva Dagmar - RGM: 31619363
 * Beatriz dos Santos Silva - RGM: 31146171
 * Maria Luísa Cavalcante - RGM: 31200125
 */

// class Pessoa: Superclasse abstrata(que não será instanciada), "mãe" de Aluno, Instrutor e 
//Recepcionista. 
// Concede todas suas características e comportamentos para suas "filhas".
// 
public abstract class Pessoa {
    private String Nome;
    private int idade;
    private String sexo;
    
    // métodos 
    
    public void fazerAniversario(){
        this.idade++; // esse método acrescenta 1 ano em idade 
    }
    
    // métodos especiais 
    
    public String getNome() {
        return Nome;
    }

    public void setNome(String Nome) {
        this.Nome = Nome;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    @Override // mostrar dados de Pessoa 
    public String toString() {
        return "Dados{" + "Nome=" + Nome + ", idade=" + idade + ", sexo=" + sexo + '}';
    }
   
}
