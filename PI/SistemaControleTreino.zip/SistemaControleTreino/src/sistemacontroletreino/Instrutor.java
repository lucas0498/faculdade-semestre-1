package sistemacontroletreino;
/**
 *
 * @author 
 * Lucas Gonçalves - RGM: 31104894
 * Joey da Silva Dagmar - RGM: 31619363
 * Beatriz dos Santos Silva - RGM: 31146171
 * Maria Luísa Cavalcante - RGM: 31200125
 */
public class Instrutor extends Pessoa {//Instrutor estende características e comportamentos de Pessoa 
      //que estende Pessoa(nome, idade, sexo, fazerAniversario())
      private String especialidade;
      private float salario;
       private boolean presente;
    
     //construtor
     public Instrutor(String especialidade, float salario, boolean presente) {
        this.especialidade = especialidade;
        this.salario = salario; 
        this.presente = presente;
    }

    
    public void darAula(boolean recepcionista){  // MÉTODOS darAula() = POLIMORFISMO DE SOBRECARGA
        if(recepcionista){ // falar com recepcionista 
            System.out.println("Preciso checar minha agenda de treinos...");
        }
    }
        
    
    public void darAula(String fala){
        if(fala.equals("estou pronto") || fala.equals("olá")){
            System.out.println("Pegar ficha de Treino");
        }else{
            System.out.println("Falar com outro aluno");
        }
    }
    
      public void darAula(int hora, int minuto){
        if(hora > 8 && hora < 12 ){
            System.out.println("Bom dia! Pronto pra se fMalhar?");
        }else if( hora >=12 && hora <14){
            this.presente = !this.presente;
            System.out.println("Estou indo almoçar... Depois nos falamos!");
        }else if(hora >=14 && hora < 17){
            System.out.println("Boa tarde! Bora treinar...");
        }else{
            System.out.println("indisponível");
            this.presente = !this.presente;
        }
    }

    public void receberAumento(float aum){ //esse método recebe valor de aumento e acrescenta ao salário
       this.salario += aum;
    }
    
    public String getEspecialidade() {
        return especialidade;
    }

    public void setEspecialidade(String especialidade) {
        this.especialidade = especialidade;
    }

    public float getSalario() {
        return salario;
    }

    public void setSalario(float salario) {
        this.salario = salario;
    }

    public boolean getPresente() {
        return presente;
    }

    public void setPresente(boolean presente) {
        this.presente = presente;
    }
    
}
