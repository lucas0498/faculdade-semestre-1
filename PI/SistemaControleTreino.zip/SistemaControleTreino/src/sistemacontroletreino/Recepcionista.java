package sistemacontroletreino;

/**
 *
 * @author 
 * Lucas Gonçalves - RGM: 31104894
 * Joey da Silva Dagmar - RGM: 31619363
 * Beatriz dos Santos Silva - RGM: 31146171
 * Maria Luísa Cavalcante - RGM: 31200125
 */
//Recepcionista estende características e comportamentos de Pessoa(nome, idade, sexo, fazerAniversario()) 
public class Recepcionista extends Pessoa  {
    public boolean trabalhando;
    
    //construtor
    public Recepcionista(boolean trabalhando) {
        this.trabalhando = trabalhando;
    }
    
    
    public void mudaTrabalho(){ //com esse método this.trabalando recebe o inverso de this.trabalhando 
        //Se ele não estiver trabalhando muda para trabalhando 
        this.trabalhando = !this.trabalhando;
    }

    public boolean getTrabalhando() {
        return trabalhando;
    }

    public void setTrabalhando(boolean trabalhando) {
        this.trabalhando = trabalhando;
    }
    
}
