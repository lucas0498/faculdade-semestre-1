package sistemacontroletreino;

/**
 *
 * @author 
 * Lucas Gonçalves - RGM: 31104894
 * Joey da Silva Dagmar - RGM: 31619363
 * Beatriz dos Santos Silva - RGM: 31146171
 * Maria Luísa Cavalcante - RGM: 31200125
 */
public class SistemaControleTreino {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        // iniciando o sistema criando Alunos, Instrutores e recepcionista
        
        Aluno a[] = new Aluno[2];
        a[0] = new Aluno(1234,"Iniciante");
        a[1] = new Aluno(1234,"Iniciante");
        
        
        Instrutor i[] = new Instrutor[2];
        i[0] = new Instrutor("Musculação",4500.00f, true);// true coloca o instrutor para trabalhar
        i[1] = new Instrutor("Musculação",4500.00f, false);
        
        
        Recepcionista r[] = new Recepcionista[2];
        r[0] = new Recepcionista(false);
        r[1] = new Recepcionista(true);// true coloca o recepcinista para trabalhar
        
        
        
        Treino UTI01 = new Treino();  
        UTI01.marcarTreino(i[0],a[1] );// marcar treino entre Instrutor i[] e Alunos a[]
        UTI01.Treinar();
    } 
    
}
