package sistemacontroletreino;

import java.util.Scanner;

/**
 *
 * @author 
 * Lucas Gonçalves - RGM: 31104894
 * Joey da Silva Dagmar - RGM: 31619363
 * Beatriz dos Santos Silva - RGM: 31146171
 * Maria Luísa Cavalcante - RGM: 31200125
 */
//Aluno estende características e comportamentos de Pessoa(nome, idade, sexo, fazerAniversario())
public class Aluno extends Pessoa {
    // atributos 
    private int matricula;
    private String treino; 
    
    
    //construtor
    
     public Aluno(int matricula, String treino) {
        this.matricula = matricula;
        this.treino = treino;
    }
    
    
     public void cancelarMatricula(){
        String x;
        Scanner sc = new Scanner(System.in);
          System.out.println("Tem certeza que deseja cancelar sua matrícula? sim/não");
          x = sc.next();
          if(x.equals("sim")){
          System.out.println("Matrícula cancelada com sucesso " + this.getNome());
          }else{
              System.out.println("Não entendi. Por favor, fale com um de nossos recepcionistas.");
          }
    }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public String getTreino() {
        return treino;
    }

    public void setTreino(String curso) {
        this.treino = curso;
    }
    
}
